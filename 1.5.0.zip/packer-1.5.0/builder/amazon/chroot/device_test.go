package chroot

import "testing"

func TestDevicePrefixMatch(t *testing.T) {
	/*
		if devicePrefixMatch("nvme0n1") != "" {
		}
	*/
}
